**UNFINISHED!**

http://www.freedomhouse.org/report/special-reports/leaping-over-firewall-review-censorship-circumvention-tools

https://en.wikipedia.org/wiki/Internet_censorship_circumvention#Reverse_Proxy

https://en.wikipedia.org/wiki/Flash_proxy

http://www.scotty-transporter.org/

http://jaxov.com/2009/09/how-to-unblock-any-website-in-ubuntu-via-ultrasurf-linux/

https://s3.amazonaws.com/0ubz-2q11-gi9y/en.html

https://en.wikipedia.org/wiki/Psiphon

https://www.your-freedom.net/

https://socialsourcecommons.org/tool/show/3368/

http://www.vpngate.net/en/

https://telex.cc/

http://lahana.dreamcats.org/

Questions:

 * Type? (VPN, proxy, ssh?)
 * Usable with Open Source Software, without any proprietary client? (OpenVPN etc.)
 * Is there a Linux version?
 * Does it work in WINE?
 * Can Whonix (Tor) get tunneled through it? (Whonix (Tor) can get tunneled thought a VPN running on the host and also supports all kinds of proxy settings (http(s), socks4(a)/5).)
 * Instructions?