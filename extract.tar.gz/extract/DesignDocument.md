# Introduction #
The Whonix [DesignDocument] Document is based on [DesignDocumentBase]

**Outdated: Superseded by [Design] page.**

[[include ref=WikiHeader]]

[TOC]

# Isolated environment – which will only communicate with the external network via Tor - Design Document #
Original authors:
***Martin Peck** <coderman at gmail dot com>***
***Kyle Williams** <kyle.kwilliams at gmail dot com>***
***Copyright © 2008-2009**The Tor Project, Inc***.

[Forked](https://en.wikipedia.org/wiki/Fork_%28software_development%29) by **adrelanos** because the original developers were gone and no development was going on anymore.

February 23, 2012

# Legal Notice #
You may distribute or modify this document according to the terms of the [GNU Free Documentation License Version 1.2 or later](http://www.gnu.org/licenses/fdl-1.2.txt). 
"BSD® is a registered trademark of UUnet Technologies, Inc." 
"Linux® is the registered trademark of Linus Torvalds in the U.S. and other countries." 
"Tor® is a registered trademark of The Tor Project, Inc." 
"VMware® is a registered trademark of VMware, Inc. in the United States and other jurisdictions." 
"Windows® is a registered trademark of Microsoft Corporation in the United States and other countries."

# 1. Introduction #

This document describes a transparent Tor™ proxy design for Ubuntu Linux and possibly other Linux distributions or BSD using a virtual machine platform. An overview of the transparent proxy approach is provided in addition to design goals and implementation detail.

## 1.1. Privacy and Anonymity ##

Privacy is the ability to selectively disclose information about yourself and who you share it with. Tor is a privacy enhancing technology designed to provide low latency anonymity on the Internet against an adversary who can generate, modify, or delete traffic, run malicious Tor nodes, and perform other attacks against participants in the network.

Using the nymity slider as reference Tor aims to provide Unlinkable Anonymity for its users. A poor implementation of Tor may expose the user to set reduction attacks eroding privacy to Linkable Anonymity. A more effective attack could further degrade user privacy to Persistent Pseudonymity via a unique identifier, for example. And worst case side channel attacks that reveal origin IP address can void all of the privacy intent of the Tor software. These side channel or catastrophic attacks completely defeat the privacy goals of Tor and indicate a failure of the implementation.

## 1.2. Transparent Proxy Overview ##

A [Tor proxy](http://wiki.noreply.org/noreply/TheOnionRouter/TransparentProxy transparent) operates at the network and transport layers of of the OSI model instead of the usual application layer like SOCKS or HTTP. Intercepting and routing traffic in this manner avoids the risk of catastrophic side channel attacks that pose the most significant risk to privacy, particularly in a Windows environment.

Usability is also improved as manual SOCKS or HTTP proxy configuration is no longer necessary in each anonymized application. Software that does not support any kind of proxy feature can also be supported in this manner without any additional effort.

## 1.3. Isolated (Virtual) Machine Advantages ##

A isolated (virtual) machine environment can further improve the security position by providing defense in depth against attacks which rely on using local applications to make requests to Tor that can compromise anonymity. This benefit is mainly achieved through the use of isolated network stacks in the Tor-Gateway and the Tor-Workstation. Separate stacks ensure that by default applications on one the Tor-Workstation cannot communicate with any other unless explicitly configured to do so. This is in contrast to the usual localhost idiom which assumes connections to/from 127.0.0.1 are protected from external threats.

Separate network stacks also simplify the implementation of a transparent proxy approach by using existing networking facilities to route traffic to the isolated (virtual) machine as a default gateway instead of using more complicated traffic classification and redirection within the host network stack. This is important in a Windows environment where capabilities like Linux® netfilter or BSD® packet filter do not exist.

For Windows platforms offloading the TCP session intensive Tor process to a Linux guest with [edge triggered IO](http://monkey.org/~provos/libevent/) can significantly improve the performance of Tor and eliminate [socket buffer problems](http://wiki.noreply.org/noreply/TheOnionRouter/WindowsBufferProblems).

## 1.4. Application Isolation and Consistency ##

The use of multiple Tor-Workstations to isolate application instances can protect against linkability of user communications by providing a consistent and trusted initial state for anonymous applications using a static (virtual) machine image to ensure that any changes made within that isolated environment are not persisted from one runtime instance to the next.

This fixed (virtual) machine state is critical for using otherwise dangerous software like browser plugins that can write persistent and unique identifying information to hard disk and relay this information to an attacker.

## 2. Tor VM Design ##

The transparent Tor proxy virtual machine must provide a usable and secure interface to the Tor network that preserves the unlinkable anonymity intent of Tor. A number of design criteria are necessary to achieve this goal.
2.1. Threat Model

A number of threats are expected when using the Tor network for anonymous communication over the Internet.

**Attacker Intent**
   ***Identify User Endpoint** 
    One goal of the attacker within this threat model is to obtain the Tor user origin IP address.

   ***Identify User Verinym** 
    The attacker may desire uniquely identifying user information like name and address stored on the host computer.

   ***Reduce Privacy to Persistent Pseudonym** 
    While not as useful as the identifying information above the attacker may wish to uniquely track the individuals using Tor even if their true identities remain unknown.
    
   ***Link Anonymous Communications** 
    The attacker may also attempt to correlate anonymous communications from the same user with each other. 

**Attacker Capabilities and Methods** 
   ***Proxy Bypass** 
    If the attacker can inject some kind of content to invoke a client request that bypasses application proxy settings they can achieve their goal of determining user endpoint. Social engineering attacks which entice a user to make a request that may bypass proxy settings are also included in this class of techniques.

   ***DNS Requests** 
    The attacker may also attempt to have the user application make a DNS request that does not resolve through Tor in order to expose the origin endpoint. This can often be accomplished when proxy settings are otherwise honored correctly.

   ***Combined Local and Remote Attacks** 
    Another effective attack vector is the use of local and remote resources in a coordinated attack against a client system. One example of this approach is injecting a malicious Java applet into web requests which in turn uses the sun.net.spi.nameservice.dns.DNSNameService and related parameters to request explicit DNS resolution from a DNS server on the local subnet. Many transparent proxy implementations that rely on the default route alone to direct traffic through Tor are vulnerable to this and other similar techniques.

   ***Partitioning Attacks** 
    The attacker may observe distinguishing characteristics of Tor user traffic to partition the anonymity set of some users over time into progressively smaller and smaller sets. When this set becomes a set of one individual they can [track individual activity](https://torbutton.torproject.org/dev/design/#fingerprinting) and likely achieve their goal of identifying user endpoint.

   ***Linking Attacks via Persistent State** 
    The attacker may use files or application state stored on disk to link separate instances of Tor use with each other. Note that unique identifiers or configuration associated with applications or operating system components can be used to link communications from the same user if exposed to an attacker.

   ***Fingerprinting Attacks** 
    The attacker may obtain as much information as possible about the application and environment it is running in to obtain a set of parameters unique to each pseudonym targeted.

   ***Full Remote Code Execution Attacks** 
    Vulnerabilities in applications or configuration may be exploited remotely for arbitrary execution of the attackers code. This will typically grant access to most of the files and configuration on the operating system. 

**Indefensible Attacks** 
   ***Tor Attacks** 
    Attacks which Tor cannot defend against, like a global passive adversary or traffic confirmation attacks, are obviously outside the scope of even the most robust Tor implementation.

   ***Some Remote Exploit and Arbitrary Execution Attacks** 
    Attacks which leverage an application or operating system flaw to gain full remote code execution on the host system are not defensible. This highlights the need for secure hosts when relying on Tor for anonymity. An untrusted host cannot provide a trusted Tor instance, regardless of how robust the implementation may be otherwise.

    The multiple (virtual) machine model provides defense in depth against these types of attacks and may constrain the scope of any compromise to the single virtual machine instance affected by the exploit. It is possible (though hard to quantify how difficult) to escalate from a compromised machine to secondary exploit to the Tor-Gateway (or the host OS), again rendering all protections ineffective.

    The user is suggested to harden it's (virtual) machines in the [Security Guide].

   ***Some Correlation Attacks** 
    If a Tor user interacts with the same site or service when using Tor and not using Tor it is likely trivial for an attacker to correlate the anonymous activity with the original user, and thus achieve their goal of identifying origin endpoint. Users must be aware of the absolute necessity of keeping anonymous services separate from directly accessed services and never mix the two.

    The ability to switch between anonymous and direct access to such services requires a strong separation of state, like that provided by [TorButton](http://torbutton.torproject.org/dev/design/), which is too complicated and restrictive to apply to the entire spectrum of applications and protocols that may be used over a transparent Tor proxy implementation. For this reason a "toggle" capability is explicitly not included in the design goals for this implementation. 

    The [Warning] page in Whonix states "*Do not connect to any server anonymously and non-anonymously at the same time!*".

**Attacks Difficult to Defend Against Transparently** 
   ***Partitioning and Fingerprinting Attacks** 
    While side channel attacks can be thwarted effectively with a robust transparent Tor implementation it is more difficult to protect the content of the communications from partitioning or fingerprinting attacks. The use of TorButton and other such tools is encouraged to provide additional defense against these attacks. Application virtual machines may be difficult to implement for the full spectrum of applications in a way that defeats these attacks.

   ***The Faithless Endpoint** 
    Another difficult problem for Tor implementations is the opportunity for malicious exit nodes to observe and manipulate traffic from their router to compromise user privacy and security. The Faithless Endpoint details a number of risks that users may not be aware of.

    Educating the user about these risks in an intuitive manner and providing them tools to prevent unintended exposure to malicious participants in the Tor network is a complicated effort. It's not possible to describe and circumvent all those risks. The most command risks are described in the [Documentation] providing workarounds.

## 2.2. Design Requirements ##

The risks identified in the threat model above drive a number of design criteria necessary to thwart or mitigate compromise of user privacy.

**Transparent Proxy Requirements** 
   **1. Proxy All TCP and DNS Traffic** 
    All TCP and DNS traffic must be routed through the Tor-Gateway. This requires that no local subnets be exposed on the Tor-Workstation network stack once started to prevent the combined local and remote DNS exploits described above.
    
   **2. Filter Remaining Traffic** 
    Traffic that is not TCP or DNS must be dropped at the Tor VM instance to prevent forwarding potentially sensitive multicast, UDP, ICMP, or other datagrams to the upstream router(s). This ensures that certain protocols, like SMTP and NetBIOS, are filtered as soon as they leave the Tor-Workstation.

   **3. Fail Safely** 
    If the Tor-Gateway is unable to proxy traffic it must not let the traffic through unaltered, but instead drop it.

**Virtual Machine Requirements**
   **1. Open Source** 
    While VMware® is one of the more friendly and stable VM implementations, it lacks the transparency necessary for a robust security position and also precludes bundling into a portable Tor VM.

   **2. NAT Adapter Support** 
    To support the widest range of client uses a NAT network adapter is required within the Virtual Machine implementation used by Tor VM. Most of the potential VM platforms support this mode of operation by default.

   **3. Low Host OS Overhead** 
    A VM platform that provides low host memory and CPU consumption improves the usability and stability of Tor VM in addition to making it suitable for a wider range of older or less powerful hardware users may have. This is particularly important for graphical applications and other media intensive virtual machine instances.

   **4. Isolation and Integrity Protections** 
    The ability to run multiple (virtual) machines for application runtime isolation and defense in depth against unknown application or guest operating system vulnerabilities is required. Kernel level VM acceleration is potentially useful, however, the expanded attack surface presented by such acceleration layers should be considered carefully. 

**Host and Tor-Gateway Requirements**
   **1. IP Routing Through Tor VM** 
    All operating systems that are able to run Tor should be able to route traffic in the manner required for transparent proxy through the (virtual) machine. Using the NAT adapter configuration there is no need to rely on VPN or DHCP resources for Tor VM functionality; basic IP interface configuration and IP routing facilities are all that is necessary.

   **2. Privilege Separation** 
    To obtain the most benefit of a transparent (virtual) machine implementation host access controls and privilege separation should be used to  constrain the capabilities of the implementation and the applications used with it. Newer Windows versions go beyond the typical owner / group based distinction into fine grained access control which may be useful.

**User Interface Requirements**
   **1. Native GUI Controller** 
    Vidalia is an existing feature rich and well known controller for Tor on Windows and other operating systems that would provide much of the interface desired. This requires that an acceptably secure method of allowing control port access to the Tor-Gateway instance from the Host.

    A hashed control password generated randomly at start is used by Vidalia to authenticate to Tor. This is passed to the VM kernel but never stored on disk. This would allow control port access without connection behavior changes with the limitation that any Vidalia restart requires a restart of the VM as well. 

    [TorController]

# 3. Tor VM Implementation #

A solution that satisfies these requirements can be implemented using a variety of GNU/Linux and Win32 software. The open source licenses associated with these tools ensure that adequate scrutiny of the code base supporting a Tor virtual machine is possible for those who choose to evaluate it.

# 3.1. Build Environment #

The following dependencies are required for building the Tor VM image and supporting VM tools.

    .

## 3.2. Virtual Machine Software ##

Three virtual machine implementations were considered and tested: VMware, VirtualBox and Bochs. NAT adapter support is available in all implementations. The GPL license applied to VirtualBox and Bochs code base satisfies the open source requirement.

Bochs provides full CPU emulation for much stronger host / guest isolation and does not require any changes to the guest kernel or system level drivers on the host.

VirtualBox is much faster because it is a virtualizer and not an emulator, it also does not require any changes to the guest kernel or system level drivers on the host. For these reasons VirtualBox is preferred for the virtual machine implementation despite the increased CPU and memory overhead associated with full emulation.

## 3.3. Tor VM Build ##
How to build Whonix is documented in [BuildDocumentation].

## 3.4. Tor Configuration ##
Configuration of Whonix is documented in Whonix source code whonnix_workstation/etc/tor/torrc.

## 3.5. Persistent Storage ##
Many protections built into Tor to protect against various types of attacks against Tor client anonymity rely on a persistent data storage facility of some kind that preserves cached network status, saved keys and configuration, and other critical capabilities. There are a number of ways to configure the virtual disk storage for the VM based on the role of the node in the network and the environment where it resides. The Tor-Gateway has a hard drive, which Tor may use.

## 3.6. Host Virtual Machine Integration ##

Usability is a critical part of any Tor implementation. Providing a responsive and intuitive interface for the Tor implementation and the applications routing through it is a particularly difficult problem in the context of the threats detailed above.

Any effective methods of improving usability should be considered.

**Virtual Machine and Application Management**
   **Run As Service**
    The ability to run a persistent instance of the Tor-Gateway as a service on the host would also be useful.

   **VirtualBox additions**
    Kernel level virtual machine acceleration is particularly useful for running graphical applications with SVGA displays and high color depth. The VirtualBox additions can provide a useful performance increase for these graphical applications. 

**Multi-VM Model**

    .

## 3.7. Network Configuration ##

A robust transparent Tor proxy implementation requires careful configuration of the routing and filtering of traffic on both the host and guest OS instances.

Network Configuration of Whonix is documented in Whonix source code in /etc/network/interfaces.

## 3.8. User Interface ##

    .

# 4. See also #
* [Documentation]
* [Design]

# Footer #
[[include ref=WikiFooter]]