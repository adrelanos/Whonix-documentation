[[include ref=WikiHeader]]

This page is about the security of certain applications. For general security see [Security].

[TOC]

= Identity correlation through circuit sharing =

Moved to https://sourceforge.net/p/whonix/wiki/Stream%20Isolation/

= Application specific WARNINGS =

== General ==

Moved to https://sourceforge.net/p/whonix/wiki/Install%20Software/

== BitTorrent ==

Moved to https://sourceforge.net/p/whonix/wiki/BitTorrent/

== IRC-clients ==

Moved to https://sourceforge.net/p/whonix/wiki/XChat/

== Browser Plugins ==

Moved to https://sourceforge.net/p/whonix/wiki/BrowserPlugins/

= Whonix-Workstation is firewalled =

Moved to https://sourceforge.net/p/whonix/wiki/Install%20Software/#whonix-workstation-is-firewalled

= Other Anonymizing Networks over Tor UDP Tunnel =

Moved to https://sourceforge.net/p/whonix/wiki/Security%20Guide/#other-anonymizing-networks-over-tor-udp-tunnel

= Footer =

[[include ref=WikiFooter]]

