[[include ref=WikiHeader]]

(1). Install and start Virtual Box. Click on ''File'' -&gt; ''Import Appliance...''

[[Image:http://whonix.sourceforge.net/screenshots/install/1_start_virtualbox.png|frame|none]]

(2). Click on ''Choose''.

[[Image:http://whonix.sourceforge.net/screenshots/install/2_click_choose.png|frame|none]]

(3). Select the Whonix-Gateway.ova from your download folder and press ''open''.

[[Image:http://whonix.sourceforge.net/screenshots/install/3_navigate_and_select.png|frame|none]]

(4). Click on ''Next''.

[[Image:http://whonix.sourceforge.net/screenshots/install/4_click_next.png|frame|none]]

(5). Do not change anything! (You could do that later.) Do not change the MAC address! Just click on ''Import''.

[[Image:http://whonix.sourceforge.net/screenshots/install/5_click_import.png|frame|none]]

(6). Wait until Whonix-Gateway.ova has been imported.

[[Image:http://whonix.sourceforge.net/screenshots/install/6_wait_until_imported.png|frame|none]]

(7). Repeat the import step also for Whonix-Workstation.ova.

[[Image:http://whonix.sourceforge.net/screenshots/install/8_repeat_for_workstation.png|frame|none]]

(8). Do not change anything! (You could do that later.) Do not change the MAC address! Just click on ''Import''. [[Image:http://whonix.sourceforge.net/screenshots/install/9_click_import.png]]

(9). Wait until Whonix-Workstation.ova has been imported.

[[Image:http://whonix.sourceforge.net/screenshots/install/10_wait_until_imported.png|frame|none]]

(10). That's how it should finally look like. Click on Whonix-Gateway and on ''Start''. Then click on Whonix-Workstation and click on ''Start''. [[Image:http://whonix.sourceforge.net/screenshots/install/11_click_start.png]]

= Footer =

[[include ref=WikiFooter]]

