= Whonix-documentation =

== Download ==

<pre>git clone https://github.com/adrelanos/Whonix-documentation.git</pre>
== Re-download documentation from sourceforge ==

Must be lower case &quot;whonix&quot;.

<pre>./pull-wiki-v2.py whonix</pre>
== Convert to media wiki syntax ==

Use pandoc 1.11.1 (its only in Debian testing and from its homepage) the older version (in Debian stable) has too much bugs.

<pre>./convert-to-mediawiki</pre>
