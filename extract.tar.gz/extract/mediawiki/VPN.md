Moved to https://sourceforge.net/p/whonix/wiki/VPN-Firewall/

