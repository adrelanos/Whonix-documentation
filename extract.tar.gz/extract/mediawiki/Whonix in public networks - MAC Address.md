Moved to https://sourceforge.net/p/whonix/wiki/Pre%20Install%20Advice/

